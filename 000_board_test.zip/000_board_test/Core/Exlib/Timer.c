/*
 * Timer.c
 *
 *  Created on: Mar 11, 2020
 *      Author: okapi
 */

#include "Timer.h"

/*
 * Actions of General Purpose Timers.
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){

	if(htim->Instance == TIM2){		//1s
		return;
	}
	if(htim->Instance == TIM5){		//1ms
		return;
	}
	if(htim->Instance == TIM10){	//1s
		TogglePinState(LED_R_GPIO_Port, LED_R_Pin);
		return;
	}
	if(htim->Instance == TIM14){	//1ms
		return;
	}
}
