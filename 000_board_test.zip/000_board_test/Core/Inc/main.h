/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
#define TogglePinState(__GPIO__, __GPIO_Pin__) (((__GPIO__)->ODR) ^= (__GPIO_Pin__))

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define GPIO_J2_Pin GPIO_PIN_4
#define GPIO_J2_GPIO_Port GPIOE
#define GPIO_J1_Pin GPIO_PIN_5
#define GPIO_J1_GPIO_Port GPIOE
#define GPIO_K1_Pin GPIO_PIN_6
#define GPIO_K1_GPIO_Port GPIOE
#define GPIO_Y_Pin GPIO_PIN_7
#define GPIO_Y_GPIO_Port GPIOI
#define GPIO_X_Pin GPIO_PIN_6
#define GPIO_X_GPIO_Port GPIOI
#define GPIO_W_Pin GPIO_PIN_5
#define GPIO_W_GPIO_Port GPIOI
#define GPIO_Z_Pin GPIO_PIN_2
#define GPIO_Z_GPIO_Port GPIOI
#define GPIO_Q2_Pin GPIO_PIN_9
#define GPIO_Q2_GPIO_Port GPIOI
#define GPIO_I2_Pin GPIO_PIN_0
#define GPIO_I2_GPIO_Port GPIOF
#define GPIO_A_Pin GPIO_PIN_0
#define GPIO_A_GPIO_Port GPIOI
#define POWER3_PWM_Pin GPIO_PIN_9
#define POWER3_PWM_GPIO_Port GPIOA
#define POWER1_CTRL_Pin GPIO_PIN_2
#define POWER1_CTRL_GPIO_Port GPIOH
#define POWER_PWM4_Pin GPIO_PIN_8
#define POWER_PWM4_GPIO_Port GPIOA
#define POWER2_CTRL_Pin GPIO_PIN_3
#define POWER2_CTRL_GPIO_Port GPIOH
#define GPIO_I1_Pin GPIO_PIN_1
#define GPIO_I1_GPIO_Port GPIOF
#define POWER3_CTRL_Pin GPIO_PIN_4
#define POWER3_CTRL_GPIO_Port GPIOH
#define POWER4_CTRL_Pin GPIO_PIN_5
#define POWER4_CTRL_GPIO_Port GPIOH
#define SPI5_NSS_OUTPUT_Pin GPIO_PIN_6
#define SPI5_NSS_OUTPUT_GPIO_Port GPIOF
#define GPIO_B_Pin GPIO_PIN_12
#define GPIO_B_GPIO_Port GPIOH
#define GPIO_Q1_Pin GPIO_PIN_10
#define GPIO_Q1_GPIO_Port GPIOF
#define GPIO_C_Pin GPIO_PIN_11
#define GPIO_C_GPIO_Port GPIOH
#define GPIO_D_Pin GPIO_PIN_10
#define GPIO_D_GPIO_Port GPIOH
#define GPIO_E_Pin GPIO_PIN_15
#define GPIO_E_GPIO_Port GPIOD
#define GPIO_N2_Pin GPIO_PIN_0
#define GPIO_N2_GPIO_Port GPIOC
#define GPIO_O2_Pin GPIO_PIN_1
#define GPIO_O2_GPIO_Port GPIOC
#define GPIO_L1_Pin GPIO_PIN_2
#define GPIO_L1_GPIO_Port GPIOC
#define GPIO_M1_Pin GPIO_PIN_3
#define GPIO_M1_GPIO_Port GPIOC
#define GPIO_F_Pin GPIO_PIN_14
#define GPIO_F_GPIO_Port GPIOD
#define GPIO_G_Pin GPIO_PIN_13
#define GPIO_G_GPIO_Port GPIOD
#define GPIO_T_Pin GPIO_PIN_1
#define GPIO_T_GPIO_Port GPIOA
#define GPIO_S_Pin GPIO_PIN_0
#define GPIO_S_GPIO_Port GPIOA
#define GPIO_P2_Pin GPIO_PIN_4
#define GPIO_P2_GPIO_Port GPIOA
#define GPIO_N1_Pin GPIO_PIN_4
#define GPIO_N1_GPIO_Port GPIOC
#define POWER1_PWM_Pin GPIO_PIN_13
#define POWER1_PWM_GPIO_Port GPIOE
#define GPIO_H_Pin GPIO_PIN_12
#define GPIO_H_GPIO_Port GPIOD
#define GPIO_U_Pin GPIO_PIN_2
#define GPIO_U_GPIO_Port GPIOA
#define GPIO_P1_Pin GPIO_PIN_5
#define GPIO_P1_GPIO_Port GPIOA
#define GPIO_O1_Pin GPIO_PIN_5
#define GPIO_O1_GPIO_Port GPIOC
#define LED_R_Pin GPIO_PIN_11
#define LED_R_GPIO_Port GPIOE
#define POWER2_PWM_Pin GPIO_PIN_14
#define POWER2_PWM_GPIO_Port GPIOE
#define GPIO_V_Pin GPIO_PIN_3
#define GPIO_V_GPIO_Port GPIOA
#define GPIO_M2_Pin GPIO_PIN_1
#define GPIO_M2_GPIO_Port GPIOB
#define GPIO_L2_Pin GPIO_PIN_0
#define GPIO_L2_GPIO_Port GPIOB
#define LED_G_Pin GPIO_PIN_14
#define LED_G_GPIO_Port GPIOF
#define GPIO_K2_Pin GPIO_PIN_12
#define GPIO_K2_GPIO_Port GPIOE
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
